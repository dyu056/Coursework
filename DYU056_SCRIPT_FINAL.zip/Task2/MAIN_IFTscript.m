clc;clear;
addpath(fullfile(pwd, '/functions'));
iters = 50;
% Kp_initial = 48.3686;
% Ki_initial = 11.7573;
% Kd_initial = 41.2577;
Kp_initial = 1;
Ki_initial = 0.1;
Kd_initial = 1;
end_time = 6;
kp = Kp_initial;
ki = Ki_initial;
kd = Kd_initial;
model = 'MotorSlider';
Ts = 0.01; %Set by user
% Calculation error and record
t = 0:Ts:1;
u = 0.2*ones(1,length(t));
simin = timeseries(u,t);
sim_output = sim(model,end_time);
figure;
plot(sim_output.Velocity,'DisplayName','Optimized gain from linear model')
title("The comparison of time response for saturation case")
xlabel("Time (s)")
ylabel("Velocity (m/s)")

Options = simset('SrcWorkSpace','current');
stepsize = 1;
%% Testing function
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, end_time)
figure
plot(J_list)
title("Cost function vs iterations for linear model")
xlabel("Iteration")
ylabel("J")
%% Store J_list for plottting
stepsize = 2;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, end_time)
J_list_1 = J_list;
Kp_1 = Kp;
Ki_1 = Ki;
Kd_1 = Kd;
%% Store J_list for plottting
stepsize = 1.5;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, end_time)
J_list_2 = J_list;
Kp_2 = Kp;
Ki_2 = Ki;
Kd_2 = Kd;
%% Store J_list for plottting
stepsize = 1;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, end_time)
J_list_3 = J_list;
Kp_3 = Kp;
Ki_3 = Ki;
Kd_3 = Kd;
%% Store J_list for plottting
stepsize = 0.5;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, end_time)
J_list_4 = J_list;
Kp_4 = Kp;
Ki_4 = Ki;
Kd_4 = Kd;
%% Store J_list for plottting
stepsize = 0.1;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, end_time)
J_list_5 = J_list;
Kp_5 = Kp;
Ki_5 = Ki;
Kd_5 = Kd;
%% Store J_list for plottting
stepsize = 0.05;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, end_time)
J_list_6 = J_list;
Kp_6 = Kp;
Ki_6 = Ki;
Kd_6 = Kd;
%% Store J_list for plottting
stepsize = 0.01;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, end_time)
J_list_7 = J_list;
Kp_7 = Kp;
Ki_7 = Ki;
Kd_7 = Kd;
%% Store J_list for plottting
stepsize = 0.005;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, end_time)
J_list_8 = J_list;
Kp_8 = Kp;
Ki_8 = Ki;
Kd_8 = Kd;
%% Store J_list for plottting
stepsize = 0.001;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, end_time)
J_list_9 = J_list;
Kp_9 = Kp;
Ki_9 = Ki;
Kd_9 = Kd;

%% Plot J evolution for different setpoint sizes
figure
yyaxis right
plot(J_list_1(8:end),'DisplayName','setpoint size = 2')
hold on
plot(J_list_2,'DisplayName','setpoint size = 1.5')
plot(J_list_3,'DisplayName','setpoint size = 1')
plot(J_list_4,'DisplayName','setpoint size = 0.5')
plot(J_list_5,'DisplayName','setpoint size = 0.1')
plot(J_list_6,'DisplayName','setpoint size = 0.05')
yyaxis left
plot(J_list_7,'DisplayName','setpoint size = 0.01')
hold on
plot(J_list_8,'DisplayName','setpoint size = 0.005')
plot(J_list_9,'DisplayName','setpoint size = 0.001')
title("Cost function vs iterations for linear model")
xlabel("Iteration")
ylabel("J")
%% Pick the gain with minimized cost function for realistic model
[MinimumJ_1,Index] = min(J_list_6);
Kp_minimum_1 = Kp_6(Index);
Ki_minimum_1 = Ki_6(Index);
Kd_minimum_1 = Kd_6(Index);
%% Plot result and compare
%Declare initial PID parameters
model = 'MotorSlider';
kp = 81.8122;
ki = 8.3636;
kd = 49.0118;
Ts = 0.01; %Set by user
% Calculation error and record
t = 0:Ts:1;
u = ones(1,length(t));
simin = timeseries(u,t);
sim_output = sim(model,1);
figure;
plot(sim_output.Velocity,'DisplayName','Local minimum at (81.8122,8.3636,49.0118), J = 2.6866e-5')
title("Time response of motor velocity from realistic model")
xlabel("Time (s)")
ylabel("Velocity (m/s)")
hold on
model = 'MotorSlider';
kp = 55.7337;
ki = 10.0149;
kd = 42.6083;
Ts = 0.01; %Set by user
% Calculation error and record
t = 0:Ts:1;
u = ones(1,length(t));
simin = timeseries(u,t);
sim_output = sim(model,1);
plot(sim_output.Velocity,'DisplayName','Local minimum at (55.7337,10.0149,42.6083), J = 2.6032e-5')
title("Time response of motor velocity from realistic model")
xlabel("Time (s)")
ylabel("Velocity (m/s)")

%% Plot result for comparison between realistic and simulated
%Declare initial PID parameters
model = 'MotorSlider_linear';
Kp_initial = 49.989;
Ki_initial = 10.188;
Kd_initial = 41.673;
kp = Kp_initial;
ki = Ki_initial;
kd = Kd_initial;
Ts = 0.01; %Set by user
% Calculation error and record
t = 0:Ts:1;
u = 0.2*ones(1,length(t));
simin = timeseries(u,t);
sim_output = sim(model,0.5);
figure;
plot(sim_output.Velocity,'DisplayName','Optimized gain from linear model')
title("The comparison of time response for saturation case")
xlabel("Time (s)")
ylabel("Velocity (m/s)")
hold on
model = 'MotorSlider';
kp = 55.7337;
ki = 10.0149;
kd = 42.6083;
Ts = 0.01; %Set by user
% Calculation error and record
t = 0:Ts:1;
u = 0.2*ones(1,length(t));
simin = timeseries(u,t);
sim_output = sim(model,0.5);
plot(sim_output.Velocity,'DisplayName','Optimized gain for realistic model')

%% Copy and paster following into the function would give the same, the following script is used to facilitate debugging process
J_list = zeros(1, iters);
Kp = zeros(1, iters);
Ki = zeros(1, iters);
Kd = zeros(1, iters);
djdkp_list = zeros(1,iters);
djdki_list = zeros(1,iters);
djdkd_list = zeros(1,iters);
% Add your IFT code here!
% You may find the "sim" function useful for calling Simulink models.

for i = 1:1:iters
    %Declare initial PID parameters
    if i == 1
       Kp(i) = Kp_initial;
       Ki(i) = Ki_initial;
       Kd(i) = Kd_initial;
    end
    kp = Kp(i);
    ki = Ki(i);
    kd = Kd(i);
    Ts = 0.01; %Set by user
    
    % Calculation error and record
    t = 0:Ts:10;
    u = ones(1,length(t));
    simin = timeseries(u,t);
    sim_output = sim(model,'SrcWorkSpace','current');
    error_series = sim_output.error;  %r - y
    if strcmp(model,'MotorSlider')
        error = error_series * -1; %y - r
        error_series = timeseries(error_series,t);
    else
        error = error_series.Data * -1;  %y - r
    end
    N = length(error);
    local_J = sum(error.^2)/(2*N);

    % Plot result
    string1 = 'Loop';
    string2 = int2str(i);
    string = append(string1,string2);
    plot(sim_output.Velocity,'DisplayName',string);
    hold on
    legend
    
    %Calculate dydp from error
    simin = error_series;
    sim_output = sim(model,'SrcWorkSpace','current');
    dydkp = sim_output.dydkp.Data;
    dydki = sim_output.dydki.Data;
    dydkd = sim_output.dydkd.Data;
    time = sim_output.dydkd.Time;
    N = length(time);

    % Calculation for next step
    p = [kp;ki;kd];

    J_list(i) = local_J;
    disp(J_list)
    dJdkp = sum(error.*dydkp)/N;
    dJdki = sum(error.*dydki)/N;
    dJdkd = sum(error.*dydkd)/N;
    djdkp_list(i) = dJdkp;
    djdki_list(i) = dJdki;
    djdkd_list(i) = dJdkd;
    dJdp = [dJdkp;dJdki;dJdkd];
    
    H = zeros(3,3);
    for j = 1:1:N
        dydp = [dydkp(j);dydki(j);dydkd(j)];
        local_H = dydp*transpose(dydp); 
        H = H + local_H;
    end
    H = H / N;
    %H = eye(3);

    new_p = p - stepsize*(inv(H)*dJdp);
    
    if i < iters
        Kp(i+1) = new_p(1);
        Ki(i+1) = new_p(2);
        Kd(i+1) = new_p(3);
    end
end

%% Figure plotting
figure;
plot(djdki_list);
%% Study about the behavior of cost function (2d)
clc;clear;
iters = 14;
Kp_initial = 1;
Ki_initial = 1;
Kd_initial = 1;
model = 'MotorSlider';
J_list = zeros(iters, iters);
dJdkp_list = zeros(iters, iters);
dJdki_list = zeros(iters, iters);
Kp = linspace(1,100,iters);
Ki = linspace(1,100,iters);
Kd = linspace(1,100,iters);
% Add your IFT code here!
% You may find the "sim" function useful for calling Simulink models.

for i = 1:1:iters
    for j = 1:1:iters
        %Declare initial PID parameters
        kp = Kp(i);
        ki = Ki_initial;
        kd = Kd(j);
        Ts = 0.01; %Set by user
        % Calculation error and record
        t = 0:Ts:10;
        u = ones(1,length(t));
        simin = timeseries(u,t);
        
        sim_output = sim(model);
        error_series = sim_output.error;
        if strcmp(model,'MotorSlider')
            error = error_series * -1; %y - r
            error_series = timeseries(error_series,t);
        else
            error = error_series.Data * -1;  %y - r
        end
        N = length(error);
        local_J = sum(error.^2)/(2*N);
        
        %Calculate dydp from error
        simin = error_series;
        sim_output = sim(model);
        dydkp = sim_output.dydkp.Data;
        dydki = sim_output.dydki.Data;
        dydkd = sim_output.dydkd.Data;
        N = length(error);
        dJdp = sum(dydkp.*error)/N;
        dJdkp_list(i,j) = dJdp;
        if (local_J > 0.01)
            J_list(i,j) = 0.01;
        else
            J_list(i,j) = local_J;
        end
    end
end
% Plot J2
[X,Y] = meshgrid(Kp,Kd);
mesh(X,Y,J_list);
title("J^2(K_p,K_i)")
xlabel('Kp')
ylabel('Kd')
zlabel('J^2')

%% Study about the behavior of cost function (1d)
clc;clear;
iters = 100;
Kp_initial = 1;
Ki_initial = 1;
Kd_initial = 1;
model = 'MotorSlider';
J_list = zeros(iters, 1);
dJdkp_list = zeros(iters, 1);
dJdki_list = zeros(iters, 1);
dJdkd_list = zeros(iters, 1);
Kp = linspace(1,200,iters);
Ki = linspace(1,200,iters);
Kd = linspace(1,200,iters);
% Add your IFT code here!
% You may find the "sim" function useful for calling Simulink models.

for i = 1:1:iters
    %Declare initial PID parameters
    kp = Kp(i);
    ki = Ki_initial;
    kd = Kd_initial;
    Ts = 0.01; %Set by user

    % Calculation error and record
    t = 0:Ts:10;
    u = ones(1,length(t));
    simin = timeseries(u,t);
    sim_output = sim(model);
    error_series = sim_output.error;
    if strcmp(model,'MotorSlider')
        error = error_series * -1; %y - r
        error_series = timeseries(error_series,t);
    else
        error = error_series.Data * -1;  %y - r
    end
    N = length(error);
    local_J = sum(error.^2)/(2*N);
    
    %Calculate dydp from error
    simin = error_series;
    sim_output = sim(model);
    dydkp = sim_output.dydkp.Data;
    dydki = sim_output.dydki.Data;
    dydkd = sim_output.dydkd.Data;
    N = length(error);
    dJdkp = sum(dydkp.*error)/N;
    dJdkp_list(i) = dJdkp;
    dJdki = sum(dydki.*error)/N;
    dJdki_list(i) = dJdki;
    dJdkd = sum(dydkd.*error)/N;
    dJdkd_list(i) = dJdkd;
    if (local_J > 0.01)
        J_list(i,1) = 0.01;
    else
        J_list(i,1) = local_J;
    end
end
% Plot J2
% plot(Kp,J_list)
%% Plot function
figure;
yyaxis left;
ylabel("J")
plot(Kd, J_list,'DisplayName','J');
xline(13,'DisplayName','K_d = 13');
yyaxis right;
ylabel("dJ/dK_d")
plot(Kd, dJdkd_list,'DisplayName','dJ/dkd');
legend
title("The evolution of J and dJ/dK_d with K_d")
xlabel("Kd");
%% Plot function
figure;
yyaxis left;
ylabel("J")
plot(Ki, J_list,'DisplayName','J');
xline(13,'DisplayName','K_i = 13');
yyaxis right;
ylabel("dJ/dK_i")
plot(Ki, dJdki_list,'DisplayName','dJ/dki');
legend
title("The evolution of J and dJ/dK_i with K_i")
xlabel("Ki");
yline(0,'DisplayName','gradient = 0');
%% Plot function
figure;
yyaxis left;
ylabel("J")
plot(Kp, J_list,'DisplayName','J');
xline(157.788,'DisplayName','K_p = 157.788');
yyaxis right;
ylabel("dJ/dK_p")
plot(Kp, dJdkp_list,'DisplayName','dJ/dkp');
legend
title("The evolution of J and dJ/dK_p with K_p")
xlabel("Kp");
yline(0,'DisplayName','gradient = 0');
%% Single output of optimized plot
%Declare initial PID parameters
% kp = Kp(end);
% ki = Ki(end);
% kd = Kd(end);
kp = 6.6566;
ki = 1.6399;
kd = 62.8016;
Ts = 0.01; %Set by user
model = 'MotorSlider';
% Calculation error and record
t = 0:Ts:10;
u = ones(1,length(t));
simin = timeseries(u,t);
sim_output = sim(model,10);
error_series = sim_output.error;
error = error_series*-1;
N = length(error);
local_J = sum(error.^2)/(2*N);

%Calculate dydp from error
simin = error_series;
sim_output = sim(model);
dydkp = sim_output.dydkp.Data;
dydki = sim_output.dydki.Data;
dydkd = sim_output.dydkd.Data;
N = length(error);
dJdp = sum(dydkp.*error)/N