% This script is run before all simulations of MotorSlider.slx.
% You should put any code required to initialize your controllers here!
%Motor related in SI:
k_b = (24-24*0.073/2.28)/(8300*2*pi/60);
k_t = k_b;
R_w = 10.7884;
r_p = 0.005;
m = 0.5;  %0.5kg for weighted carriage
J = 1.5e-6;
B = 2.242e-6;
% continuous_plant = get_continuous_tf(k_b,k_t,R_w,r_p,m,J,B);
% discrete_plant = c2d(continuous_plant,Ts);