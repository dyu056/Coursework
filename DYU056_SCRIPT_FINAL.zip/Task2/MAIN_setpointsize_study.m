clc;clear;
addpath(fullfile(pwd, '/functions'));
iters = 50;
Kp_initial = 49.989;
Ki_initial = 10.188;
Kd_initial = 41.673;
% Kp_initial = 1;
% Ki_initial = 1;
% Kd_initial = 1;
Options = simset('SrcWorkSpace','current');
stepsize = 1;
endtime = 10;
model = 'MotorSlider';
% %% Testing function
% [J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, endtime)
% figure
% plot(J_list)
% title("Cost function vs iterations for linear model")
% xlabel("Iteration")
% ylabel("J")
%% Store J_list for plottting
stepsize = 2;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, endtime)
J_list_1 = J_list;
Kp_1 = Kp;
Ki_1 = Ki;
Kd_1 = Kd;
%% Store J_list for plottting
stepsize = 1.5;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, endtime)
J_list_2 = J_list;
Kp_2 = Kp;
Ki_2 = Ki;
Kd_2 = Kd;
%% Store J_list for plottting
stepsize = 1;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, endtime)
J_list_3 = J_list;
Kp_3 = Kp;
Ki_3 = Ki;
Kd_3 = Kd;
%% Store J_list for plottting
stepsize = 0.5;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, endtime)
J_list_4 = J_list;
Kp_4 = Kp;
Ki_4 = Ki;
Kd_4 = Kd;
%% Store J_list for plottting
stepsize = 0.1;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, endtime)
J_list_5 = J_list;
Kp_5 = Kp;
Ki_5 = Ki;
Kd_5 = Kd;
%% Store J_list for plottting
stepsize = 0.05;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, endtime)
J_list_6 = J_list;
Kp_6 = Kp;
Ki_6 = Ki;
Kd_6 = Kd;
%% Store J_list for plottting
stepsize = 0.01;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, endtime)
J_list_7 = J_list;
Kp_7 = Kp;
Ki_7 = Ki;
Kd_7 = Kd;
%% Store J_list for plottting
stepsize = 0.005;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, endtime)
J_list_8 = J_list;
Kp_8 = Kp;
Ki_8 = Ki;
Kd_8 = Kd;
%% Store J_list for plottting
stepsize = 0.001;
[J_list, Kp, Ki, Kd, dJdkp, dJdki, dJdkd] = ift(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, endtime)
J_list_9 = J_list;
Kp_9 = Kp;
Ki_9 = Ki;
Kd_9 = Kd;

%% Plot J evolution for different setpoint sizes
figure
plot(J_list_1(1:end),'DisplayName','setpoint size = 2')
hold on
plot(J_list_2,'DisplayName','setpoint size = 1.5')
plot(J_list_3,'DisplayName','setpoint size = 1')
plot(J_list_4,'DisplayName','setpoint size = 0.5')
plot(J_list_5,'DisplayName','setpoint size = 0.1')
plot(J_list_6,'DisplayName','setpoint size = 0.05')
plot(J_list_7,'DisplayName','setpoint size = 0.01')
plot(J_list_8,'DisplayName','setpoint size = 0.005')
plot(J_list_9,'DisplayName','setpoint size = 0.001')
title("Cost function vs iterations for realistic model")
xlabel("Iteration")
ylabel("J")
%% Pick the gain with minimized cost function
[MinimumJ_6,Index] = min(J_list_6);
Kp_minimum_6 = Kp_6(Index);
Ki_minimum_6 = Ki_6(Index);
Kd_minimum_6 = Kd_6(Index);

%% Plot one J
figure
plot(J_list_6,'DisplayName','setpoint size = 0.05')
title("Cost function vs iterations for IC = linear opt gain")
xlabel("Iteration")
ylabel("J")