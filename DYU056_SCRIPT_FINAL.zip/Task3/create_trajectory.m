% This script generates trapezoidal trajectories using MATLAB plots.
maxAcc = 0.1;
maxVel = 0.2;
timeslice = 0.001; % 1ms timeslices

figure;
hold on;
xlim([-0.475, 0.475]);
ylim([-0.450, 0.450]);

xi = [0];
yi = [0];

for i=1:100
    [x, y] = ginput(1);
    if(isempty(x))
        break;
    end
    xi = [xi, x];
    yi = [yi, y];
    plot([xi(end), xi(end-1)], [yi(end), yi(end-1)]);
end

trajpos = [];
trajvel = [];
trajacc = [];
trajtime = [];
timeoffset = 0;

for i = 2:length(xi)
    time = [];
    pos = [];
    vel = [];
    acc = [];
    now = timeoffset;
    start = [xi(i-1); yi(i-1)];
    goal = [xi(i); yi(i)];
    vec = goal - start;
    step = vec * timeslice;
    here = [0; 0];
    velnow = 0;
    while true
        if (norm(here + velnow * step) < norm(vec / 2))
            here = here + velnow * step;
            pos = [pos; here'];
            vel = [vel; velnow];
            time = [time; now];
            if velnow < maxVel
                velnow = velnow + (maxAcc * timeslice);
                acc = [acc; maxAcc];
            else
                acc = [acc; 0];
            end
            now = now + timeslice;
        else
            break;
        end
    end
    
    % We have half the trajectory here, other half is just a mirror
    % plus an extra point (not at timeslice) to reconsile the two
    splice_point = vec - here;
    splice_vec = splice_point - here;
    splice_time = norm(splice_vec / 2) / velnow;
    pos = [pos; here' + (splice_vec / 2)'];
    vel = [vel; velnow];
    acc = [acc; 0];
    time = [time; now + splice_time];
    now = now + splice_time * 2;

    for i = length(pos) - 1:-1:1
        pos = [pos; vec' - pos(i, :)];
        vel = [vel; vel(i)];
        acc = [acc; -acc(i)];
        time = [time; now];
        now = now + timeslice;
    end

    pos = pos + start';

    trajpos = [trajpos; pos];
    trajvel = [trajvel; vel];
    trajacc = [trajacc; acc];
    trajtime = [trajtime; time];
    timeoffset = now;
end

plot(trajpos(:, 1), trajpos(:, 2));

figure;
subplot(1, 3, 1);
hold on;
plot(trajtime, trajpos(:, 1));
plot(trajtime, trajpos(:, 2));
legend("X", "Y");
ylabel("Position (m)");
xlabel("Time (s)");
subplot(1, 3, 2);
plot(trajtime, trajvel);
ylabel("Speed (m/s)");
xlabel("Time (s)");
subplot(1, 3, 3);
plot(trajtime, trajacc);
ylabel("Acceleration (m/s^2)");
xlabel("Time (s)");

% Setup Simulation
in.PositionX = timeseries(trajpos(:, 1), trajtime);
in.PositionY = timeseries(trajpos(:, 2), trajtime);
