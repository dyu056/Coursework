% This script is run before all simulations of CartesianGantry.slx.
% You should put any code required to initialize your controllers here!

%% Setup
%Motor related in SI:
k_b = (24-24*0.073/2.28)/(8300*2*pi/60);
k_t = k_b;
R_w = 10.7884;
r_p = 0.005;
m = 0.5;  %0.5kg for weighted carriage
J = 1.5e-6;
B = 2.242e-6;
m_y = 2.6+0.5;
M = 0.5;
g = 9.81;
load_torque = M*g*r_p/2;
continuous_plant_x = get_continuous_tf(k_b,k_t,R_w,r_p,m,J,B);
continuous_plant_y = get_continuous_tf(k_b,k_t,R_w,r_p,m_y,J,B);
Ts = 0.01;
damping_ratio = 0.95;
settling_time = 0.1; %s
discrete_plant_x = c2d(continuous_plant_x,Ts);
discrete_plant_y = c2d(continuous_plant_y,Ts);
%% Create Deadbeat controller for xdot ydot
kpx = 48.3686;
kix = 11.7573;
kdx = 41.2577;
kpy = 2.325487895752340e+02;
kiy = 10.039840106984162;
kdy = 1.798050993349978e+02;
DeadbeatController_x = get_velocity_deadbeat_from_plant(discrete_plant_x,Ts);
DeadbeatController_y = get_velocity_deadbeat_from_plant(discrete_plant_y,Ts);
[pp_controller_velx,kp_velx,ki_velx] = get_pp_from_plant(damping_ratio,settling_time,Ts,continuous_plant_x);
[pp_controller_vely,kp_vely,ki_vely] = get_pp_from_plant(damping_ratio,settling_time,Ts,continuous_plant_y);
HandTuneController_velx = PID_hand_tune(kpx,kix,kdx,Ts); 
HandTuneController_vely = PID_hand_tune(kpy,kiy,kdy,Ts); 

VelControllerX = DeadbeatController_x;
VelControllerY = DeadbeatController_y;
ControllerNumerator_X = cell2mat(VelControllerX.Numerator);
ControllerNumerator_Y = cell2mat(VelControllerY.Numerator);
ControllerDenominator_X = cell2mat(VelControllerX.Denominator);
ControllerDenominator_Y = cell2mat(VelControllerY.Denominator);

CLTF_velx = feedback(VelControllerX,1);
CLTF_vely = feedback(VelControllerY,1);

integral = tf([0 1],[1 0]);
integral_discrete = c2d(integral,Ts);
% %% IFT calculating y
% [J_list, Kp, Ki, Kd, djdkp_list, djdki_list, djdkd_list] = ift_y(200, 1, 1, 1, 1, 'MotorSlider_linear_y', 10);
% plot(J_list)
% Kp_initial = Kp(end);
% Ki_initial = Ki(end);
% Kd_initial = Kd(end);
% %% Do again on realistic model
% [J_list, Kp, Ki, Kd, djdkp_list, djdki_list, djdkd_list] = ift_y(200, Kp_initial, Ki_initial, Kd_initial, 0.001, 'MotorSlider_y', 3);
%% Design position controller
PosController_dd_x = get_position_deadbeat_from_plant(CLTF_velx,Ts);
PosController_dd_y = get_position_deadbeat_from_plant(CLTF_vely,Ts);
HandTuneController_x = PID_hand_tune(10,0.5,3,Ts); 
HandTuneController_y = PID_hand_tune(10,0.5,10,Ts); 

PosController_x = HandTuneController_x;
PosController_y = HandTuneController_y;
FeedForwardN_Y = cell2mat(CLTF_vely.Denominator);
FeedForwardD_Y = cell2mat(CLTF_vely.Numerator);
X_POS_N = cell2mat(PosController_x.Numerator);
X_POS_D = cell2mat(PosController_x.Denominator);
Y_POS_N = cell2mat(PosController_y.Numerator);
Y_POS_D = cell2mat(PosController_y.Denominator);
% 48.3686,11.7573,41.2577