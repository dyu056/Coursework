% This function iteratively tunes the position controller
% Inputs:
%   iters - A number specifying the number of ift iterations to run
%   Kp_initial - The initial Kp gain
%   Ki_initial - The initial Ki gain
%   Kd_initial - The initial Kd gain
%   stepsize - stepsize of updating PID coefficient
%   endtime - endtime of simulation
%   model - type of model to run ('MotorSlider' realistic model, 'MotorSlider_linear' linear simulated model,
%   'MotorSlider_sim' non-linear simulated model)
% Outputs:
%   J - An iters by 1 vector containing the cost of each iteration
%   Kp - An iters by 1 vector containing the Kp gain of each iteration
%   Ki - An iters by 1 vector containing the Ki gain of each iteration
%   Kd - An iters by 1 vector containing the Kd gain of each iteration
%   djdkp_list - An iters by 1 vector containing the dJdkp of each
%   iteration
%   djdki_list - An iters by 1 vector containing the dJdki of each
%   iteration
%   djdkd_list - An iters by 1 vector containing the dJdkd of each
%   iteration

function [J_list_x,J_list_y, Kp_x, Ki_x, Kd_x, Kp_y, Ki_y, Kd_y] = ift_pos(iters, Kp_x0, Ki_x0, Kd_x0, Kp_y0, Ki_y0, Kd_y0, stepsize, endtime, shape_input)
    % Initialization
    J_list_x = zeros(1, iters);
    J_list_y = zeros(1, iters);
    Kp_x = zeros(1, iters);
    Ki_x = zeros(1, iters);
    Kd_x = zeros(1, iters);
    Kp_y = zeros(1, iters);
    Ki_y = zeros(1, iters);
    Kd_y = zeros(1, iters);

    Options = simset('SrcWorkSpace','current');

    % Define velocity controller
    kpx = 48.3686;
    kix = 11.7573;
    kdx = 41.2577;
    kpy = 2.325487895752340e+02;
    kiy = 10.039840106984162;
    kdy = 1.798050993349978e+02;
    DeadbeatController_x = get_velocity_deadbeat_from_plant(discrete_plant_x,Ts);
    DeadbeatController_y = get_velocity_deadbeat_from_plant(discrete_plant_y,Ts);
    [pp_controller_velx,kp_velx,ki_velx] = get_pp_from_plant(damping_ratio,settling_time,Ts,continuous_plant_x);
    [pp_controller_vely,kp_vely,ki_vely] = get_pp_from_plant(damping_ratio,settling_time,Ts,continuous_plant_y);
    HandTuneController_velx = PID_hand_tune(kpx,kix,kdx,Ts); 
    HandTuneController_vely = PID_hand_tune(kpy,kiy,kdy,Ts); 
    
    VelControllerX = DeadbeatController_x;
    VelControllerY = DeadbeatController_y;
    ControllerNumerator_X = cell2mat(VelControllerX.Numerator);
    ControllerNumerator_Y = cell2mat(VelControllerY.Numerator);
    ControllerDenominator_X = cell2mat(VelControllerX.Denominator);
    ControllerDenominator_Y = cell2mat(VelControllerY.Denominator);
    
    for i = 1:1:iters
        %Declare initial PID parameters
        if i == 1
           Kp_x(i) = Kp_x0;
           Ki_x(i) = Ki_x0;
           Kd_x(i) = Kd_x0;
           Kp_y(i) = Kp_y0;
           Ki_y(i) = Ki_y0;
           Kd_y(i) = Kd_y0;
        end
        kp_x = Kp_x(i);
        ki_x = Ki_x(i);
        kd_x = Kd_x(i);
        kp_y = Kp_y(i);
        ki_y = Ki_y(i);
        kd_y = Kd_y(i);

        Ts = 0.01; %Set by user
        
        % First calculation use shape input, calculate error
        in.PositionX = shape_input.PositionX;
        in.PositionY = shape_input.PositionY;

        PosController_x = PID_hand_tune(kp_x,ki_x,kd_x,Ts); 
        PosController_y = PID_hand_tune(kp_y,ki_y,kd_y,Ts); 
        X_POS_N = cell2mat(PosController_x.Numerator);
        X_POS_D = cell2mat(PosController_x.Denominator);
        Y_POS_N = cell2mat(PosController_y.Numerator);
        Y_POS_D = cell2mat(PosController_y.Denominator);
        output = sim('CartesianGantry.slx',endtime,Options);
        error_x = output.error_x * -1;  %y - r
        error_y = output.error_y * -1;  %y - r
        derivative_measure_input_x = error_x.Data * -1;
        derivative_measure_input_y = error_y.Data * -1;
        N = length(error_x);
        local_J_x = sum(error_x.^2)/(2*N);
        local_J_y = sum(error_y.^2)/(2*N);
        
%         % Plot result
%         string1 = 'Loop ';
%         string2 = num2str(i);
%         string3 = ': Kp = ';
%         string4 = num2str(kp,5);
%         string5 = ', Ki = ';
%         string6 = num2str(ki,5);
%         string7 = ', Kd = ';
%         string8 = num2str(kd,5);
%         string = append(string1,string2,string3,string4,string5,string6,string7,string8);
%         plot(sim_output.Velocity,'DisplayName',string);
%         title("Time response evolution during the optimization process");
%         xlabel("time (s)");
%         ylabel("Velocity (m/s)")
%         hold on
%         legend
        
        %Calculate dydp from error
        in.PositionX = derivative_measure_input_x;
        in.PositionY = derivative_measure_input_y;
        output = sim(model,endtime,Options);
        dydkp_x = output.dydkp_x.Data;
        dydki_x = output.dydki_x.Data;
        dydkd_x = output.dydkd_x.Data;
        dydkp_y = output.dydkp_y.Data;
        dydki_y = output.dydki_y.Data;
        dydkd_y = output.dydkd_y.Data;
        time = sim_output.dydkd_y.Time;
        N = length(time);
        
        % Calculation for next step
        p_x = [kp_x;ki_x;kd_x];
        p_y = [kp_y;ki_y;kd_y];
        
        J_list_x(i) = local_J_x;
        J_list_y(i) = local_J_y;
        disp(J_list_x)
        disp(J_list_y)
        dJdkp_x = sum(error_x.*dydkp_x)/N;
        dJdki_x = sum(error_x.*dydki_x)/N;
        dJdkd_x = sum(error_x.*dydkd_x)/N;
        dJdkp_y = sum(error_y.*dydkp_y)/N;
        dJdki_y = sum(error_y.*dydki_y)/N;
        dJdkd_y = sum(error_y.*dydkd_y)/N;
        dJdp_x = [dJdkp_x;dJdki_x;dJdkd_x];
        dJdp_y = [dJdkp_y;dJdki_y;dJdkd_y];
        
        H_x = zeros(3,3);
        for j = 1:1:N
            dydp_x = [dydkp_x(j);dydki_x(j);dydkd_x(j)];
            local_H = dydp*transpose(dydp_x); 
            H_x = H_x + local_H;
        end
        clearvars local_H;
        H_x = H_x / N;

        H_y = zeros(3,3);
        for j = 1:1:N
            dydp_y = [dydkp_y(j);dydki_y(j);dydkd_y(j)];
            local_H = dydp*transpose(dydp_y); 
            H_y = H_y + local_H;
        end
        clearvars local_H;
        H_y = H_y / N;
        
        new_p_x = p_x - stepsize*(inv(H_x)*dJdp_x);
        new_p_y = p_y - stepsize*(inv(H_y)*dJdp_y);

        if i < iters
            Kp_x(i+1) = new_p_x(1);
            Ki_x(i+1) = new_p_x(2);
            Kd_x(i+1) = new_p_x(3);
            Kp_y(i+1) = new_p_y(1);
            Ki_y(i+1) = new_p_y(2);
            Kd_y(i+1) = new_p_y(3);
        end
    end
end