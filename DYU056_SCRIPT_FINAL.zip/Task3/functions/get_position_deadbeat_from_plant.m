function DeadbeatController = get_position_deadbeat_from_plant(VelocityControlCLTF,Ts)
    integral_discrete = c2d(tf([0 1],[1 0]),Ts);
    velocity_plant = VelocityControlCLTF * integral_discrete;
    velocity_plant_numerator = cell2mat(velocity_plant.Numerator);
    velocity_plant_denominator = cell2mat(velocity_plant.Denominator);
    DeadbeatController = tf([0 0 1],[1 0 -1],Ts) * tf(velocity_plant_denominator,velocity_plant_numerator,Ts);
    OLTF_position = DeadbeatController*velocity_plant;
    CLTF_position = feedback(OLTF_position,1)
    step(CLTF_position);
end