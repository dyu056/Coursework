function [pp_controller,kp,ki] = get_pp_from_plant(damping_ratio,settling_time,Ts,continuous_plant)
    %% Set the required natural frequency, damping ratio
    natural_frequency = 4/(settling_time*damping_ratio); %rad/s
    %natural_frequency = 6.096/(settling_time); %rad/s
    % natural_frequency = 10;
    damped_frquency = natural_frequency*sqrt(1-damping_ratio^2);
    
    bandwidth = natural_frequency*sqrt(1-2*damping_ratio^2+sqrt(4*damping_ratio^4-4*damping_ratio^2+2)); %rad
    samping_frequency = 10*bandwidth;
    Ts_notround = 2*pi/samping_frequency
    %Find 2nd order polynomial for the denominator of the 2nd order cs
    a = 1;
    b = -1*2*exp(-1*damping_ratio*natural_frequency*Ts)*cos(natural_frequency*sqrt(1-damping_ratio^2)*Ts);
    c = exp(-2*damping_ratio*natural_frequency*Ts);
    %% Set the PI value to match the polynomial above
    
    % Yield from the continuous plant, the parameter of the first order plant
    plant_nominator = cell2mat(continuous_plant.Numerator);
    plant_denominator = cell2mat(continuous_plant.Denominator);
    
    % Normalized tf polynomial under the following format:
    %        k
    % T = ---------
    %      Ts + 1
    
    plant_nominator_norm = plant_nominator./plant_denominator(2);
    plant_denominator_norm = plant_denominator./plant_denominator(2);
    
    k = plant_nominator_norm(2);
    T = plant_denominator_norm(1);
    
    kp = (exp(-Ts/T)-c)/(k*(1-exp(-Ts/T)));
    ki = (b+1+exp(-Ts/T))/(k*(1-exp(-Ts/T)))-kp;
    
    % Verify the pole and zero
    discrete_plant = c2d(continuous_plant,Ts);
    pp_controller = tf([(kp+ki),-kp],[1 -1],Ts);
    OLTF = discrete_plant*pp_controller;
    CLTF = feedback(OLTF,1)
end