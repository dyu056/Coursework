% This script is run before all simulations of MotorSlider.slx.
% You should put any code required to initialize your controllers here!
%Motor related in SI:
%% Pole Placement
%Motor related in SI:
k_b = (24-24*0.073/2.28)/(8300*2*pi/60);
k_t = k_b;
R_w = 10.7884;
r_p = 0.005;
m = 0.5;  %0.5kg for weighted carriage
J = 1.5e-6;
B = 2.242e-6;
m_y = 2.6+0.5;
M = 0.5;
g = 9.81;
load_torque = M*g*r_p/2;
continuous_plant = get_continuous_tf(k_b,k_t,R_w,r_p,m,J,B);
continuous_plant_y = get_continuous_tf(k_b,k_t,R_w,r_p,m_y,J,B);
Ts = 0.01;
discrete_plant_x = c2d(continuous_plant,Ts);
discrete_plant_y = c2d(continuous_plant_y,Ts);
%% Create Deadbeat controller for x
DeadbeatController_x = get_velocity_deadbeat_from_plant(discrete_plant_x,Ts);
DeadbeatController_y = get_velocity_deadbeat_from_plant(discrete_plant_y,Ts);
ControllerNumerator_X = cell2mat(DeadbeatController_x.Numerator);
ControllerNumerator_Y = cell2mat(DeadbeatController_y.Numerator);
ControllerDenominator_X = cell2mat(DeadbeatController_x.Denominator);
ControllerDenominator_Y = cell2mat(DeadbeatController_y.Denominator);
integral = tf([0 1],[1 0]);
integral_discrete = c2d(integral,Ts);
CLTF_velx = feedback(DeadbeatController_x,1);
CLTF_vely = feedback(DeadbeatController_y,1);
%% IFT calculating y
[J_list, Kp, Ki, Kd, djdkp_list, djdki_list, djdkd_list] = ift_y(200, 1, 1, 1, 1, 'MotorSlider_linear', 10);
plot(J_list)
Kp_initial = Kp(end);
Ki_initial = Ki(end);
Kd_initial = Kd(end);
%% Do again on realistic model
[J_list, Kp, Ki, Kd, djdkp_list, djdki_list, djdkd_list] = ift_y(200, Kp_initial, Ki_initial, Kd_initial, 0.001, 'MotorSlider_y', 3);
%% Design position controller via deadbeat
PosController_x = get_position_deadbeat_from_plant(CLTF_velx,Ts);
PosController_y = get_position_deadbeat_from_plant(CLTF_vely,Ts);

X_POS_N = cell2mat(PosController_x.Numerator);
X_POS_D = cell2mat(PosController_x.Denominator);
Y_POS_N = cell2mat(PosController_y.Numerator);
Y_POS_D = cell2mat(PosController_y.Denominator);