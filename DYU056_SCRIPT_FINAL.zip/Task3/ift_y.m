% This function serves as an interface to run your IFT optimization
% You should use MotorSlider.slx for IFT tuning!
% Inputs:
%   iters - A number specifying the number of ift iterations to run
%   Kp_initial - The initial Kp gain
%   Ki_initial - The initial Ki gain
%   Kd_initial - The initial Kd gain
%   stepsize - stepsize of updating PID coefficient
%   endtime - endtime of simulation
%   model - type of model to run ('MotorSlider' realistic model, 'MotorSlider_linear' linear simulated model,
%   'MotorSlider_sim' non-linear simulated model)
% Outputs:
%   J - An iters by 1 vector containing the cost of each iteration
%   Kp - An iters by 1 vector containing the Kp gain of each iteration
%   Ki - An iters by 1 vector containing the Ki gain of each iteration
%   Kd - An iters by 1 vector containing the Kd gain of each iteration
%   djdkp_list - An iters by 1 vector containing the dJdkp of each
%   iteration
%   djdki_list - An iters by 1 vector containing the dJdki of each
%   iteration
%   djdkd_list - An iters by 1 vector containing the dJdkd of each
%   iteration

function [J_list, Kp, Ki, Kd, djdkp_list, djdki_list, djdkd_list] = ift_y(iters, Kp_initial, Ki_initial, Kd_initial, stepsize, model, endtime)
    J_list = zeros(1, iters);
    Kp = zeros(1, iters);
    Ki = zeros(1, iters);
    Kd = zeros(1, iters);
    
    % Setup of the model
    k_b = (24-24*0.073/2.28)/(8300*2*pi/60);
    k_t = k_b;
    R_w = 10.7884;
    r_p = 0.005;
    m = 2.6+0.5;  %0.5kg for weighted carriage
    J = 1.5e-6;
    B = 2.242e-6;
    load_torque = 0;

    djdkp_list = zeros(1,iters);
    djdki_list = zeros(1,iters);
    djdkd_list = zeros(1,iters);
    % Add your IFT code here!
    % You may find the "sim" function useful for calling Simulink models.
%     stepsize = 0.05;
%     model = 'MotorSlider_linear';
    Options = simset('SrcWorkSpace','current');
    
    for i = 1:1:iters
        %Declare initial PID parameters
        if i == 1
           Kp(i) = Kp_initial;
           Ki(i) = Ki_initial;
           Kd(i) = Kd_initial;
        end
        kp = Kp(i);
        ki = Ki(i);
        kd = Kd(i);
        %Apply constraint on Kd
%         if kd > 10
%             kd  = 10;
%             Kd(i) = kd;
%         elseif kd < 0
%             kd = 0;
%             Kd(i) = kd;
%         end
        %kd = 0;
        Ts = 0.01; %Set by user
        
        % Calculation error and record
        t = 0:Ts:endtime;
        u = ones(1,length(t));
        simin = timeseries(u,t);
        sim_output = sim(model,endtime,Options);
        error_series = sim_output.error;  %r - y
        if strcmp(model,'MotorSlider_y')
            error = error_series * -1; %y - r
            error_series = timeseries(error_series,t);
        else
            error = error_series.Data * -1;  %y - r
        end
        N = length(error);
        local_J = sum(error.^2)/(2*N);
        
        % Plot result
        string1 = 'Loop ';
        string2 = num2str(i);
        string3 = ': Kp = ';
        string4 = num2str(kp,5);
        string5 = ', Ki = ';
        string6 = num2str(ki,5);
        string7 = ', Kd = ';
        string8 = num2str(kd,5);
        string = append(string1,string2,string3,string4,string5,string6,string7,string8);
        plot(sim_output.Velocity,'DisplayName',string);
        title("Time response evolution during the optimization process");
        xlabel("time (s)");
        ylabel("Velocity (m/s)")
        hold on
        legend
        
        %Calculate dydp from error
        simin = error_series;
        sim_output = sim(model,endtime,Options);
        dydkp = sim_output.dydkp.Data;
        dydki = sim_output.dydki.Data;
        dydkd = sim_output.dydkd.Data;
        time = sim_output.dydkd.Time;
        N = length(time);
        
        % Calculation for next step
        p = [kp;ki;kd];
        
        J_list(i) = local_J;
        disp(J_list)
        dJdkp = sum(error.*dydkp)/N;
        dJdki = sum(error.*dydki)/N;
        dJdkd = sum(error.*dydkd)/N;
        djdkp_list(i) = dJdkp;
        djdki_list(i) = dJdki;
        djdkd_list(i) = dJdkd;
        dJdp = [dJdkp;dJdki;dJdkd];
        
        H = zeros(3,3);
        for j = 1:1:N
            dydp = [dydkp(j);dydki(j);dydkd(j)];
            local_H = dydp*transpose(dydp); 
            H = H + local_H;
        end
        H = H / N;
        %H = eye(3);
        
        new_p = p - stepsize*(inv(H)*dJdp);
        if i < iters
            Kp(i+1) = new_p(1);
            Ki(i+1) = new_p(2);
            Kd(i+1) = new_p(3);
        end
    end
end