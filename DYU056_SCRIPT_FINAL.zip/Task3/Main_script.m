clc;clear
addpath(fullfile(pwd, '/functions'));
Options = simset('SrcWorkSpace','current');

%% Setup
%Motor related in SI:
k_b = (24-24*0.073/2.28)/(8300*2*pi/60);
k_t = k_b;
R_w = 10.7884;
r_p = 0.005;
m = 0.5;  %0.5kg for weighted carriage
J = 1.5e-6;
B = 2.242e-6;
m_y = 2.6+0.5;
M = 0.5;
g = 9.81;
load_torque = M*g*r_p/2;
continuous_plant_x = get_continuous_tf(k_b,k_t,R_w,r_p,m,J,B);
continuous_plant_y = get_continuous_tf(k_b,k_t,R_w,r_p,m_y,J,B);
Ts = 0.01;
damping_ratio = 0.95;
settling_time = 0.1; %s
discrete_plant_x = c2d(continuous_plant_x,Ts);
discrete_plant_y = c2d(continuous_plant_y,Ts);
%% Create Deadbeat controller for xdot ydot
kpx = 48.3686;
kix = 11.7573;
kdx = 41.2577;
kpy = 2.325487895752340e+02;
kiy = 10.039840106984162;
kdy = 1.798050993349978e+02;
DeadbeatController_x = get_velocity_deadbeat_from_plant(discrete_plant_x,Ts);
DeadbeatController_y = get_velocity_deadbeat_from_plant(discrete_plant_y,Ts);
[pp_controller_velx,kp_velx,ki_velx] = get_pp_from_plant(damping_ratio,settling_time,Ts,continuous_plant_x);
[pp_controller_vely,kp_vely,ki_vely] = get_pp_from_plant(damping_ratio,settling_time,Ts,continuous_plant_y);
HandTuneController_velx = PID_hand_tune(kpx,kix,kdx,Ts); 
HandTuneController_vely = PID_hand_tune(kpy,kiy,kdy,Ts); 

VelControllerX = DeadbeatController_x;
VelControllerY = DeadbeatController_y;
ControllerNumerator_X = cell2mat(VelControllerX.Numerator);
ControllerNumerator_Y = cell2mat(VelControllerY.Numerator);
ControllerDenominator_X = cell2mat(VelControllerX.Denominator);
ControllerDenominator_Y = cell2mat(VelControllerY.Denominator);

CLTF_velx = feedback(VelControllerX,1);
CLTF_vely = feedback(VelControllerY,1);

integral = tf([0 1],[1 0]);
integral_discrete = c2d(integral,Ts);
% %% IFT calculating y
% [J_list, Kp, Ki, Kd, djdkp_list, djdki_list, djdkd_list] = ift_y(200, 1, 1, 1, 1, 'MotorSlider_linear_y', 10);
% plot(J_list)
% Kp_initial = Kp(end);
% Ki_initial = Ki(end);
% Kd_initial = Kd(end);
% %% Do again on realistic model
% [J_list, Kp, Ki, Kd, djdkp_list, djdki_list, djdkd_list] = ift_y(200, Kp_initial, Ki_initial, Kd_initial, 0.001, 'MotorSlider_y', 3);
%% Design position controller
PosController_dd_x = get_position_deadbeat_from_plant(CLTF_velx,Ts);
PosController_dd_y = get_position_deadbeat_from_plant(CLTF_vely,Ts);
HandTuneController_x = PID_hand_tune(10,0.5,3,Ts); 
HandTuneController_y = PID_hand_tune(10,0.5,10,Ts); 

PosController_x = HandTuneController_x;
PosController_y = HandTuneController_y;
FeedForwardN_Y = cell2mat(CLTF_vely.Denominator);
FeedForwardD_Y = cell2mat(CLTF_vely.Numerator);
X_POS_N = cell2mat(PosController_x.Numerator);
X_POS_D = cell2mat(PosController_x.Denominator);
Y_POS_N = cell2mat(PosController_y.Numerator);
Y_POS_D = cell2mat(PosController_y.Denominator);
% 48.3686,11.7573,41.2577
%% Run simulation
load("rectangle.mat");
end_time = 30;
% u = ones(length(t),1);
% in.PositionX = timeseries(u,t);
% in.PositionY = timeseries(u,t);
out_simulation = sim("CartesianGantry_simulated",end_time);
%% Run realistic
out_realistic = sim("CartesianGantry",end_time,Options);
%% Plot both sim and rel
avg_error_simulation = sum(sqrt(out_simulation.error_x.Data.^2+out_simulation.error_y.Data.^2))/length(out_simulation.error_x.Data);
avg_error_realistic = sum(sqrt(out_realistic.error_x.^2+out_realistic.error_y.^2))/length(out_realistic.error_x);

figure;
%plot(in.PositionX.Data,in.PositionY.Data,'DisplayName','Reference');
plot(permute(in.PositionX.Data(1,1,:),[3,1,2]),permute(in.PositionY.Data(1,1,:),[3,1,2]),'DisplayName','Reference');
% plot(permute(in.PositionX.Data(1,1,:),[3,1,2]),permute(in.PositionY.Data(1,1,:),[3,1,2]));
hold on
legend_string_simulation = append('Simulation Model, RMS error = ',num2str(avg_error_simulation));
plot(out_simulation.carriageX.Data,out_simulation.carriageY.Data,'-','DisplayName',legend_string_simulation);
legend_string_realistic = append('Realistic model, RMS error = ',num2str(avg_error_realistic));
plot(out_realistic.carriageX.Data,out_realistic.carriageY.Data,'--','DisplayName',legend_string_realistic);
axis equal;
title("Comparison between realistic and simulation model")
xlabel('x position (m)')
ylabel('y position (m)')
legend

%% Plot position x tracking
figure;
J_x_sim = sum(out_simulation.error_x.Data.^2)/(2*length(out_simulation.error_x));
J_y_sim = sum(out_simulation.error_y.Data.^2)/(2*length(out_simulation.error_x));
J_x_rel = sum(out_realistic.error_x.^2)/(2*length(out_realistic.error_x));
J_y_rel = sum(out_realistic.error_y.^2)/(2*length(out_realistic.error_x));
plot(in.PositionX,'DisplayName','Reference');
hold on
plot(out_simulation.carriageX,'.','DisplayName',append('Simulation Model, J = ',num2str(J_x_sim)));
plot(out_realistic.carriageX,'.','DisplayName',append('Realistic Model, J = ',num2str(J_x_rel)));
title("Position tracking comparison, X")
xlabel('t (s)')
ylabel('x position (m)')
legend

figure;
plot(in.PositionY,'DisplayName','Reference');
hold on
plot(out_simulation.carriageY,'.','DisplayName',append('Simulation Model, J = ',num2str(J_y_sim)));
plot(out_realistic.carriageY,'.','DisplayName',append('Realistic Model, J = ',num2str(J_y_rel)));
title("Position tracking comparison, Y")
xlabel('t (s)')
ylabel('y position (m)')
legend