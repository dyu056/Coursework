% Check the smallest time vector
if out.tout(end) < in.PositionX.Time(end)
    resample_tvec = out.tout;
else
    resample_tvec = in.PositionX.Time;
end

xref = resample(in.PositionX, resample_tvec);
yref = resample(in.PositionY, resample_tvec);
xout = resample(out.carriageX, resample_tvec);
yout = resample(out.carriageY, resample_tvec);

figure;
hold on;
plot(xout.Data, yout.Data);
plot(xref.Data, yref.Data);
legend("Output", "Reference");
title("Position");
xlabel("X (m)");
ylabel("Y (m)");

figure;
subplot(2, 1, 1);
hold on;
plot(xout);
plot(xref);
legend("Output", "Reference");
title("Position");
xlabel("X (m)");
ylabel("Time (s)");
subplot(2, 1, 2);
hold on;
plot(yout);
plot(yref);
legend("Output", "Reference");
title("Position");
xlabel("Y (m)");
ylabel("Time (s)");