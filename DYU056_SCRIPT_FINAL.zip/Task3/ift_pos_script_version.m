% This function iteratively tunes the position controller
% Inputs:
%   iters - A number specifying the number of ift iterations to run
%   Kp_initial - The initial Kp gain
%   Ki_initial - The initial Ki gain
%   Kd_initial - The initial Kd gain
%   stepsize - stepsize of updating PID coefficient
%   endtime - endtime of simulation
%   model - type of model to run ('MotorSlider' realistic model, 'MotorSlider_linear' linear simulated model,
%   'MotorSlider_sim' non-linear simulated model)
% Outputs:
%   J - An iters by 1 vector containing the cost of each iteration
%   Kp - An iters by 1 vector containing the Kp gain of each iteration
%   Ki - An iters by 1 vector containing the Ki gain of each iteration
%   Kd - An iters by 1 vector containing the Kd gain of each iteration
%   djdkp_list - An iters by 1 vector containing the dJdkp of each
%   iteration
%   djdki_list - An iters by 1 vector containing the dJdki of each
%   iteration
%   djdkd_list - An iters by 1 vector containing the dJdkd of each
%   iteration
clc;clear
load("spiral.mat");
iters = 1000;
Kp_x0 = 10;
Ki_x0 = 0.5;
% Kd_x0 = 100.6224;
Kd_x0 = 3;
Kp_y0 = 10;
Ki_y0 = 0.5;
Kd_y0 = 10;
% Kd_y0 = 88.7913;
stepsize = 0.01;
endtime = 40;
shape_input = in;
model = 'CartesianGantry_linear';
% function [J_list_x,J_list_y, Kp_x, Ki_x, Kd_x, Kp_y, Ki_y, Kd_y] = ift_pos(iters, Kp_x0, Ki_x0, Kd_x0, Kp_y0, Ki_y0, Kd_y0, stepsize, endtime, shape_input)
    % Initialization
    k_b = (24-24*0.073/2.28)/(8300*2*pi/60);
    k_t = k_b;
    R_w = 10.7884;
    r_p = 0.005;
    m = 0.5;  %0.5kg for weighted carriage
    J = 1.5e-6;
    B = 2.242e-6;
    m_y = 2.6+0.5;
    M = 0.5;
    g = 9.81;
    load_torque = M*g*r_p/2;
    continuous_plant_x = get_continuous_tf(k_b,k_t,R_w,r_p,m,J,B);
    continuous_plant_y = get_continuous_tf(k_b,k_t,R_w,r_p,m_y,J,B);
    Ts = 0.01;
    damping_ratio = 0.95;
    settling_time = 0.1; %s
    discrete_plant_x = c2d(continuous_plant_x,Ts);
    discrete_plant_y = c2d(continuous_plant_y,Ts);

    J_list_x = zeros(1, iters);
    J_list_y = zeros(1, iters);
    Kp_x = zeros(1, iters);
    Ki_x = zeros(1, iters);
    Kd_x = zeros(1, iters);
    Kp_y = zeros(1, iters);
    Ki_y = zeros(1, iters);
    Kd_y = zeros(1, iters);
    dJdkp_x_l = zeros(1, iters);
    dJdki_x_l = zeros(1, iters);
    dJdkd_x_l = zeros(1, iters);
    dJdkp_y_l = zeros(1, iters);
    dJdki_y_l = zeros(1, iters);
    dJdkd_y_l = zeros(1, iters);

    Options = simset('SrcWorkSpace','current');

    % Define velocity controller
    kpx = 48.3686;
    kix = 11.7573;
    kdx = 41.2577;
    kpy = 2.325487895752340e+02;
    kiy = 10.039840106984162;
    kdy = 1.798050993349978e+02;
    DeadbeatController_x = get_velocity_deadbeat_from_plant(discrete_plant_x,Ts);
    DeadbeatController_y = get_velocity_deadbeat_from_plant(discrete_plant_y,Ts);
    [pp_controller_velx,kp_velx,ki_velx] = get_pp_from_plant(damping_ratio,settling_time,Ts,continuous_plant_x);
    [pp_controller_vely,kp_vely,ki_vely] = get_pp_from_plant(damping_ratio,settling_time,Ts,continuous_plant_y);
    HandTuneController_velx = PID_hand_tune(kpx,kix,kdx,Ts); 
    HandTuneController_vely = PID_hand_tune(kpy,kiy,kdy,Ts); 
    
    VelControllerX = HandTuneController_velx;
    VelControllerY = HandTuneController_vely;
    ControllerNumerator_X = cell2mat(VelControllerX.Numerator);
    ControllerNumerator_Y = cell2mat(VelControllerY.Numerator);
    ControllerDenominator_X = cell2mat(VelControllerX.Denominator);
    ControllerDenominator_Y = cell2mat(VelControllerY.Denominator);
    
    figure;
    for i = 1:1:iters
        %Declare initial PID parameters
        if i == 1
           Kp_x(i) = Kp_x0;
           Ki_x(i) = Ki_x0;
           Kd_x(i) = Kd_x0;
           Kp_y(i) = Kp_y0;
           Ki_y(i) = Ki_y0;
           Kd_y(i) = Kd_y0;
        end
        kp_x = Kp_x(i);
        ki_x = Ki_x(i);
        kd_x = Kd_x(i);
        kp_y = Kp_y(i);
        ki_y = Ki_y(i);
        kd_y = Kd_y(i);

        Ts = 0.01; %Set by user
        t = 0:Ts:endtime;
        % First calculation use shape input, calculate error
        in.PositionX = shape_input.PositionX;
        in.PositionY = shape_input.PositionY;

        PosController_x = PID_hand_tune(kp_x,ki_x,kd_x,Ts); 
        PosController_y = PID_hand_tune(kp_y,ki_y,kd_y,Ts); 
        X_POS_N = cell2mat(PosController_x.Numerator);
        X_POS_D = cell2mat(PosController_x.Denominator);
        Y_POS_N = cell2mat(PosController_y.Numerator);
        Y_POS_D = cell2mat(PosController_y.Denominator);
        output = sim(model,endtime,Options);
        error_x = output.error_x * -1;  %y - r
        error_y = output.error_y * -1;  %y - r
        derivative_measure_input_x = output.error_x;
        derivative_measure_input_y = output.error_y;
        N = length(error_x);
        local_J_x = sum(error_x.^2)/(2*N);
        local_J_y = sum(error_y.^2)/(2*N);
        
        % Plot result
        plot(J_list_x,'.','DisplayName','J_x');
        hold on
        plot(J_list_y,'*','DisplayName','J_y');

        %Calculate dydp from error
        in.PositionX = timeseries(derivative_measure_input_x,t);
        in.PositionY = timeseries(derivative_measure_input_y,t);
        output = sim(model,endtime,Options);
        dydkp_x = output.dydkp_x.Data;
        dydki_x = output.dydki_x.Data;
        dydkd_x = output.dydkd_x.Data;
        dydkp_y = output.dydkp_y.Data;
        dydki_y = output.dydki_y.Data;
        dydkd_y = output.dydkd_y.Data;
        time = output.dydkd_y.Time;
        N = length(time);
        
        % Calculation for next step
        p_x = [kp_x;ki_x;kd_x];
        p_y = [kp_y;ki_y;kd_y];
        
        J_list_x(i) = local_J_x;
        J_list_y(i) = local_J_y;
        disp(J_list_x)
        disp(J_list_y)
        dJdkp_x = sum(error_x.*dydkp_x)/N;
        dJdki_x = sum(error_x.*dydki_x)/N;
        dJdkd_x = sum(error_x.*dydkd_x)/N;
        dJdkp_y = sum(error_y.*dydkp_y)/N;
        dJdki_y = sum(error_y.*dydki_y)/N;
        dJdkd_y = sum(error_y.*dydkd_y)/N;
        dJdkp_x_l(i) = dJdkp_x;
        dJdki_x_l(i) = dJdki_x;
        dJdkd_x_l(i) = dJdkd_x;
        dJdkp_y_l(i) = dJdkp_y;
        dJdki_y_l(i) = dJdki_y;
        dJdkd_y_l(i) = dJdkd_y;
        dJdp_x = [dJdkp_x;dJdki_x;dJdkd_x];
        dJdp_y = [dJdkp_y;dJdki_y;dJdkd_y];
        
        H_x = zeros(3,3);
        for j = 1:1:N
            dydp_x = [dydkp_x(j);dydki_x(j);dydkd_x(j)];
            local_H = dydp_x*transpose(dydp_x); 
            H_x = H_x + local_H;
        end
        clearvars local_H;
        H_x = H_x / N;

        H_y = zeros(3,3);
        for j = 1:1:N
            dydp_y = [dydkp_y(j);dydki_y(j);dydkd_y(j)];
            local_H = dydp_y*transpose(dydp_y); 
            H_y = H_y + local_H;
        end
        clearvars local_H;
        H_y = H_y / N;
        
        new_p_x = p_x + stepsize*(inv(H_x)*dJdp_x);
        new_p_y = p_y + stepsize*(inv(H_y)*dJdp_y);

        if i < iters
            Kp_x(i+1) = new_p_x(1);
            Ki_x(i+1) = new_p_x(2);
            Kd_x(i+1) = new_p_x(3);
            Kp_y(i+1) = new_p_y(1);
            Ki_y(i+1) = new_p_y(2);
            Kd_y(i+1) = new_p_y(3);
        end
    end
% end
%% Plotting and study
J_list = sqrt(J_list_x.^2 + J_list_y.^2);
figure;
plot(J_list);

%% Pick optimal value
J_list = sqrt(J_list_x.^2 + J_list_y.^2);
[min_J,I] = min(J_list);
Kp_x_final = Kp_x(I);
Ki_x_final = Ki_x(I);
Kd_x_final = Kd_x(I);
Kp_y_final = Kp_y(I);
Ki_y_final = Ki_y(I);
Kd_y_final = Kd_y(I);