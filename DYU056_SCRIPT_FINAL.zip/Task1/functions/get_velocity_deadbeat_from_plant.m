function DeadbeatController = get_velocity_deadbeat_from_plant(discrete_plant,Ts)
    CancellerNumerator = cell2mat(discrete_plant.Denominator);
    CancellerDenominator = cell2mat(discrete_plant.Numerator);
    Order = length(CancellerNumerator);
    ReversePlant = tf(CancellerNumerator,CancellerDenominator,Ts);
    CausalFix = tf([0 0 1],[0 1 -1], Ts);
    DeadbeatController = ReversePlant*CausalFix;
    OLTF = DeadbeatController*discrete_plant;
    CLTF = feedback(OLTF,1)
end