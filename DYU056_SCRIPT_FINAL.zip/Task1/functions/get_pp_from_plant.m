function [pp_controller,kp,ki,Ts_maximum] = get_pp_from_plant(OS,settling_time,Ts,continuous_plant)
    %% Set the required natural frequency, damping ratio
    damping_ratio = -log(OS)/sqrt(pi^2+(log(OS)^2));
    natural_frequency = 4/(settling_time*damping_ratio); %rad/s
    
    bandwidth = natural_frequency*sqrt(1-2*damping_ratio^2+sqrt(4*damping_ratio^4-4*damping_ratio^2+2)); %rad
    samping_frequency = 10*bandwidth;
    Ts_maximum = 2*pi/samping_frequency;
    
    %Find 2nd order polynomial for the denominator of the 2nd order cs
    a = 1;
    b = -1*2*exp(-1*damping_ratio*natural_frequency*Ts)*cos(natural_frequency*sqrt(1-damping_ratio^2)*Ts);
    c = exp(-2*damping_ratio*natural_frequency*Ts);
    %% Set the PI value to match the polynomial above
    
    % Yield from the continuous plant, the parameter of the first order plant
    plant_nominator = cell2mat(continuous_plant.Numerator);
    plant_denominator = cell2mat(continuous_plant.Denominator);
    
    plant_nominator_norm = plant_nominator./plant_denominator(2);
    plant_denominator_norm = plant_denominator./plant_denominator(2);
    
    k = plant_nominator_norm(2);
    T = plant_denominator_norm(1);
    
    kp = (exp(-Ts/T)-c)/(k*(1-exp(-Ts/T)));
    ki = (b+1+exp(-Ts/T))/(k*(1-exp(-Ts/T)))-kp;
    
    % Verify the pole and zero
    discrete_plant = c2d(continuous_plant,Ts);
    pp_controller = tf([(kp+ki),-kp],[1 -1],Ts);
    OLTF = discrete_plant*pp_controller;
    CLTF = feedback(OLTF,1)

    ideal_plot_continuous = tf([0 0 natural_frequency^2],[1 2*damping_ratio*natural_frequency natural_frequency^2]);
    ideal_plant_from_continuous = c2d(ideal_plot_continuous,Ts)
    step(CLTF)
    hold on
    step(ideal_plant_from_continuous);
    legend CLTF Desired_Response
end