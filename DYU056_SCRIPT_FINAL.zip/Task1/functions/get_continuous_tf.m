function sys = get_continuous_tf(k_b,k_t,R_w,r_p,m,J,B)
    numerator = r_p*k_t;
    denominator = [2*R_w*(J+(1/4)*m*r_p^2) (2*B*R_w+2*k_b*k_t)];
    sys = tf(numerator,denominator);