%% Initialization
%Please use this file after switching the manual switch in the simulink
%file "MotorSlider_Pole_Placement" and "MotorSlider_simulated"
clc;clear
addpath(fullfile(pwd, '/functions'));
Options = simset('SrcWorkSpace','current');
Ts = 0.01;
end_time = 10;
%% Parameter setup
%Motor related in SI:
k_b = (24-24*0.073/2.28)/(8300*2*pi/60);
k_t = k_b;
R_w = 10.7884;
r_p = 0.005;
m = 0.5;  %0.5kg for weighted carriage
J = 1.5e-6;
B = 2.242e-6;
continuous_plant = get_continuous_tf(k_b,k_t,R_w,r_p,m,J,B);
discrete_plant = c2d(continuous_plant,Ts);
%% Test plant (Pull the manual switch in the simulink first before testing the plant)
t_ref = 0:Ts:end_time;
simin = timeseries(ones(length(t_ref),1),t_ref)
ControllerNumerator = [1];
ControllerDenominator = [1];
simulation_result = sim('MotorSlider_simulated.slx',end_time,Options);
realistic_result = sim('MotorSlider_Pole_Placement.slx',end_time,Options);

%Plot the velocity step response from the plant
plot(simulation_result.Velocity,'DisplayName','Model Plant');
hold on
plot(realistic_result.Velocity,'DisplayName','Realistic Plant');
title("The velocity step response of plants")
xlabel("time (s)")
ylabel("velocity (m/s)")
legend