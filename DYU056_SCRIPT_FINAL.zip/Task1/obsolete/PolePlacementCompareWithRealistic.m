clc;clear
Options = simset('SrcWorkSpace','current');
end_time = 10;
%% Pole Placement
%Motor related in SI:
k_b = (24-24*0.073/2.28)/(8300*2*pi/60);
k_t = k_b;
R_w = 24/2.28;
R_w = 10.78;
r_p = 0.005;
m = 0.5;  %0.5kg for weighted carriage
J = 1.5e-6;
B = 0.00918*60/(7000*2*pi);
B = 2.4e-6;
M = 0;
g = 9.81;
% load_torque = M*g*r_p/2;
load_torque = 0;
% sim_result = sim('MotorSlider_theomodel_LOAD.slx');
continuous_plant = get_continuous_tf(k_b,k_t,R_w,r_p,m,J,B);
%% Set the required natural frequency, damping ratio
damping_ratio = 0.95;
settling_time = 0.1; %s
natural_frequency = 4/(settling_time*damping_ratio); %rad/s
%natural_frequency = 6.096/(settling_time); %rad/s
% natural_frequency = 10;
damped_frquency = natural_frequency*sqrt(1-damping_ratio^2);

bandwidth = natural_frequency*sqrt(1-2*damping_ratio^2+sqrt(4*damping_ratio^4-4*damping_ratio^2+2)); %rad
samping_frequency = 10*bandwidth;
Ts_notround = 2*pi/samping_frequency;
Ts = round(Ts_notround,4);
Ts = 0.01;

%Find 2nd order polynomial for the denominator of the 2nd order cs
a = 1;
b = -1*2*exp(-1*damping_ratio*natural_frequency*Ts)*cos(natural_frequency*sqrt(1-damping_ratio^2)*Ts);
c = exp(-2*damping_ratio*natural_frequency*Ts);

polynomial = [a b c];

ideal_plot = tf([0 0 1],polynomial,Ts);
ideal_plot_continuous = tf([0 0 natural_frequency^2],[1 2*damping_ratio*natural_frequency natural_frequency^2]);
ideal_plant_from_continuous = c2d(ideal_plot_continuous,Ts);
% step(ideal_plot)
%% Set the PI value to match the polynomial above

% Yield from the continuous plant, the parameter of the first order plant
plant_nominator = cell2mat(continuous_plant.Numerator);
plant_denominator = cell2mat(continuous_plant.Denominator);

% Normalized tf polynomial under the following format:
%        k
% T = ---------
%      Ts + 1

plant_nominator_norm = plant_nominator./plant_denominator(2);
plant_denominator_norm = plant_denominator./plant_denominator(2);

k = plant_nominator_norm(2);
T = plant_denominator_norm(1);

kp = (exp(-Ts/T)-c)/(k*(1-exp(-Ts/T)));
ki = (b+1+exp(-Ts/T))/(k*(1-exp(-Ts/T)))-kp;

% Verify the pole and zero
discrete_plant = c2d(continuous_plant,Ts);
PI_controller = tf([(kp+ki),-kp],[1 -1],Ts);
OLTF = discrete_plant*PI_controller;
CLTF = feedback(OLTF,1);
% step(CLTF)
ControllerNumerator = cell2mat(PI_controller.Numerator);
ControllerDenominator = cell2mat(PI_controller.Denominator);

%% Plot simulated
t = 0:Ts:end_time;
% rpm = 8;
rpm = 100;
% r = ones(length(t),1)*(rpm*2*pi/60)*0.5*0.005;
r = ones(length(t),1);
% r = sin(t)*(rpm*2*pi/60)*0.5*0.005;
simin = timeseries(r,t);
sim_result_sim = sim('MotorSlider_simulated.slx',end_time,Options);
figure
plot(sim_result_sim.Velocity,'DisplayName','Simulated system');
hold on
% m = 1;
sim_result_real = sim('MotorSlider_Pole_Placement.slx',end_time,Options);
plot(sim_result_real.Velocity,'DisplayName','Realistic system');
plot(simin,'DisplayName','0.01sin(t)')
title("Setpoint tracking comparison")
xlabel("time (s)")
ylabel("Velocity (m/s)")

%% Compare deadbeat
