%% Initialization
clc;clear
addpath(fullfile(pwd, '/functions'));
Options = simset('SrcWorkSpace','current');
Ts = 0.01;
%% Parameter setup
%Motor related in SI:
k_b = (24-24*0.073/2.28)/(8300*2*pi/60);
k_t = k_b;
R_w = 10.7884;
r_p = 0.005;
m = 0.5;  %0.5kg for weighted carriage
J = 1.5e-6;
B = 2.242e-6;
continuous_plant = get_continuous_tf(k_b,k_t,R_w,r_p,m,J,B);
discrete_plant = c2d(continuous_plant,Ts);

%% Design PI controller via pole placement
settling_time = 0.1;
% OS = 7.0627e-05;
OS = 0.01;
[pp_controller,kp,ki,Ts_maximum] = get_pp_from_plant(OS,settling_time,Ts,continuous_plant);

%% Design Deadbeat Controller (CLTF = 1/z)
DeadbeatController = get_velocity_deadbeat_from_plant(discrete_plant,Ts);

%% Study of pole placement controller with different B
end_time = 1;
t = 0:Ts:end_time;
r = ones(length(t),1);
step = timeseries(r,t);
simin = step;
ControllerNumerator = cell2mat(pp_controller.Numerator);
ControllerDenominator = cell2mat(pp_controller.Denominator);
B = 2.242e-6;
sim_result_B1 = sim('MotorSlider_simulated.slx',end_time,Options);
B = 5e-6;
sim_result_B2 = sim('MotorSlider_simulated.slx',end_time,Options);

figure
plot(sim_result_B1.Velocity,'DisplayName','B = 2.242e-6');
hold on
plot(step,'DisplayName','Input')  
hold on
plot(sim_result_B2.Velocity,'DisplayName',append('B = ', num2str(B)));
title("Step response of simulated system")
xlabel("time (s)")
ylabel("Velocity (m/s)")
legend
B = 2.242e-6;
%% Study of pole placement controller with different mass
end_time = 1;
t = 0:Ts:end_time;
r = ones(length(t),1);
step = timeseries(r,t);
simin = step;
ControllerNumerator = cell2mat(pp_controller.Numerator);
ControllerDenominator = cell2mat(pp_controller.Denominator);
m = 0.5;
sim_result_B1 = sim('MotorSlider_simulated.slx',end_time,Options);
m = 1;
sim_result_B2 = sim('MotorSlider_simulated.slx',end_time,Options);

figure
plot(sim_result_B1.Velocity,'DisplayName','B = 2.242e-6');
hold on
plot(step,'DisplayName','Input')  
hold on
plot(sim_result_B2.Velocity,'DisplayName',append('m = ', num2str(m)));
title("Step response of simulated system")
xlabel("time (s)")
ylabel("Velocity (m/s)")
legend
m = 0.5;

%% Study of pole placement controller with different Rw
end_time = 1;
t = 0:Ts:end_time;
r = ones(length(t),1);
step = timeseries(r,t);
simin = step;
ControllerNumerator = cell2mat(pp_controller.Numerator);
ControllerDenominator = cell2mat(pp_controller.Denominator);
R_w = 10.7884;
sim_result_B1 = sim('MotorSlider_simulated.slx',end_time,Options);
R_w = 20;
sim_result_B2 = sim('MotorSlider_simulated.slx',end_time,Options);

figure
plot(sim_result_B1.Velocity,'DisplayName','R_w = 10.7884');
hold on
plot(step,'DisplayName','Input')  
hold on
plot(sim_result_B2.Velocity,'DisplayName',append('R_w = ', num2str(R_w)));
title("Step response of simulated system")
xlabel("time (s)")
ylabel("Velocity (m/s)")
legend
R_w = 10.7884;
%% Study of pole placement controller with different k_t
end_time = 1;
t = 0:Ts:end_time;
r = ones(length(t),1);
step = timeseries(r,t);
simin = step;
ControllerNumerator = cell2mat(pp_controller.Numerator);
ControllerDenominator = cell2mat(pp_controller.Denominator);
k_t = 0.0267;
sim_result_B1 = sim('MotorSlider_simulated.slx',end_time,Options);
k_t = 0.05;
sim_result_B2 = sim('MotorSlider_simulated.slx',end_time,Options);

figure
plot(sim_result_B1.Velocity,'DisplayName','k_t = 0.0267');
hold on
plot(step,'DisplayName','Input')  
hold on
plot(sim_result_B2.Velocity,'DisplayName',append('k_t = ', num2str(k_t)));
title("Step response of simulated system")
xlabel("time (s)")
ylabel("Velocity (m/s)")
legend
k_t = 0.0267;
%% Study of pole placement controller with different k_b
end_time = 1;
t = 0:Ts:end_time;
r = ones(length(t),1);
step = timeseries(r,t);
simin = step;
ControllerNumerator = cell2mat(pp_controller.Numerator);
ControllerDenominator = cell2mat(pp_controller.Denominator);
k_b = 0.0267;
sim_result_B1 = sim('MotorSlider_simulated.slx',end_time,Options);
k_b = 0.03;
sim_result_B2 = sim('MotorSlider_simulated.slx',end_time,Options);

figure
plot(sim_result_B1.Velocity,'DisplayName','k_b = 0.0267');
hold on
plot(step,'DisplayName','Input')  
hold on
plot(sim_result_B2.Velocity,'DisplayName',append('k_b = ', num2str(k_b)));
title("Step response of simulated system")
xlabel("time (s)")
ylabel("Velocity (m/s)")
legend
k_b = 0.0267;