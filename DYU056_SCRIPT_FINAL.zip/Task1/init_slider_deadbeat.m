% This script is run before all simulations of MotorSlider_Deadbeat.slx.
% You should put any code required to initialize your controllers here!
%% Parameter setup
%Motor related in SI:
k_b = (24-24*0.073/2.28)/(8300*2*pi/60);
k_t = k_b;
R_w = 10.7884;
r_p = 0.005;
m = 0.5;  %0.5kg for weighted carriage
J = 1.5e-6;
B = 2.242e-6;
Ts = 0.01;
continuous_plant = get_continuous_tf(k_b,k_t,R_w,r_p,m,J,B);
discrete_plant = c2d(continuous_plant,Ts);
DeadbeatController = get_velocity_deadbeat_from_plant(discrete_plant,Ts);
ControllerNumerator = cell2mat(DeadbeatController.Numerator);
ControllerDenominator = cell2mat(DeadbeatController.Denominator);
%% Ripple free deadbeat trail
% Pp = cell2mat(discrete_plant.Denominator);
% Zp = cell2mat(discrete_plant.Numerator);
% K = 1/sum(Zp);
% integrator = tf([0 1],[1 -1],Ts);
% order = length(Pp);
% Pc = [1 1]; %Calculated by hand
% Controller = K * tf(Pp,Pc,Ts) * integrator;
% CLTF = feedback(Controller*discrete_plant,1)
% 
% ControllerNumerator = cell2mat(Controller.Numerator);
% ControllerDenominator = cell2mat(Controller.Denominator);