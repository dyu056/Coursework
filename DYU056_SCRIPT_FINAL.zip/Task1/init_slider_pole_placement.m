% This script is run before all simulations of MotorSlider_Pole_Placement.slx.
% You should put any code required to initialize your controllers here!

%% Parameter setup
%Motor related in SI:
k_b = (24-24*0.073/2.28)/(8300*2*pi/60);
k_t = k_b;
R_w = 10.7884;
r_p = 0.005;
m = 0.5;  %0.5kg for weighted carriage
J = 1.5e-6;
B = 2.242e-6;
continuous_plant = get_continuous_tf(k_b,k_t,R_w,r_p,m,J,B);
discrete_plant = c2d(continuous_plant,Ts);
Ts = 0.01;

%% Design PI controller via pole placement
settling_time = 0.3;
OS = 0.01;
[pp_controller,kp,ki,Ts_maximum] = get_pp_from_plant(OS,settling_time,Ts,continuous_plant);
ControllerNumerator = cell2mat(pp_controller.Numerator);
ControllerDenominator = cell2mat(pp_controller.Denominator);