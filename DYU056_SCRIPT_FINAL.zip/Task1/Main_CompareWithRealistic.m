%% Initialization
clc;clear
addpath(fullfile(pwd, '/functions'));
Options = simset('SrcWorkSpace','current');
Ts = 0.01;
%% Parameter setup
%Motor related in SI:
k_b = (24-24*0.073/2.28)/(8300*2*pi/60);
k_t = k_b;
R_w = 10.7884;
r_p = 0.005;
m = 0.5;  %0.5kg for weighted carriage
J = 1.5e-6;
B = 2.242e-6;
continuous_plant = get_continuous_tf(k_b,k_t,R_w,r_p,m,J,B);
discrete_plant = c2d(continuous_plant,Ts);

%% Design PI controller via pole placement
settling_time = 0.3;
% OS = 7.0627e-05;
OS = 0.01;
[pp_controller,kp,ki,Ts_maximum] = get_pp_from_plant(OS,settling_time,Ts,continuous_plant);

%% Design Deadbeat Controller (CLTF = 1/z)
DeadbeatController = get_velocity_deadbeat_from_plant(discrete_plant,Ts);

%% Get step response result for pole-placement design (rel vs sim)
end_time = 0.5;
t = 0:Ts:end_time;
r = ones(length(t),1);
step = timeseries(r,t);
simin = step;

ControllerNumerator = cell2mat(pp_controller.Numerator);
ControllerDenominator = cell2mat(pp_controller.Denominator);
sim_result_pp_step = sim('MotorSlider_simulated.slx',end_time,Options);
rel_result_pp_step = sim('MotorSlider_Pole_Placement.slx',end_time,Options);

figure
plot(sim_result_pp_step.Velocity,'DisplayName','Simulated');
hold on
plot(step,'DisplayName','Input')  
hold on
plot(rel_result_pp_step.Velocity,'DisplayName','Real');
title("Pole-placement design")
xlabel("time (s)")
ylabel("Velocity (m/s)")
legend
%% Get step response result for deadbeat design (rel vs sim)
end_time = 0.5;
t = 0:Ts:end_time;
r = ones(length(t),1);
step = timeseries(r,t);
simin = step;

ControllerNumerator = cell2mat(DeadbeatController.Numerator);
ControllerDenominator = cell2mat(DeadbeatController.Denominator);
sim_result_db_step = sim('MotorSlider_simulated.slx',end_time,Options);
rel_result_db_step = sim('MotorSlider_Deadbeat.slx',end_time,Options);

figure
plot(sim_result_db_step.Velocity,'DisplayName','Simulated');
hold on
plot(step,'DisplayName','Input')  
hold on
plot(rel_result_db_step.Velocity,'DisplayName','Real');
title("Deadbeat design")
xlabel("time (s)")
ylabel("Velocity (m/s)")
legend
%% Low speed tracking test for pole-placement design (realistic model
end_time = 10;
t = 0:Ts:end_time;
r = ones(length(t),1);
r = sin(t)*0.001;
sinusoidal = timeseries(r,t);
simin = sinusoidal;

rel_result_pp_step = sim('MotorSlider_Pole_Placement.slx',end_time,Options);

figure
plot(sinusoidal,'DisplayName','Input')  
hold on
plot(rel_result_pp_step.Velocity,'DisplayName','Real');
title("1mm/s speed tracking")
xlabel("time (s)")
ylabel("Velocity (m/s)")
legend