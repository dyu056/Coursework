% This script is run before all simulations of MotorSlider_Pole_Placement.slx.
% You should put any code required to initialize your controllers here!

%% Initializing simplified simulink model, compare with simplified realistic model to verify dynamic
%Motor related in SI:
clc
k_b = (24-24*0.073/2.28)/(8300*2*pi/60);
k_t = k_b;
R_w = 10.7884;
r_p = 0.005;
m = 0.5;  %0.5kg for weighted carriage
J = 1.5e-6;
B = 2.242e-6;
M = 0;
g = 9.81;
% load_torque = M*g*r_p/2;
load_torque = 0;
sim_result = sim('MotorSlider_theomodel_LOAD.slx');

%% Plot
% figure
% plot(sim_result.AngularVelocity);
% figure
% plot(sim_result.Current*2);
figure
plot(sim_result.Velocity);
figure
plot(sim_result.Position);