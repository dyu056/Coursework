%% Initialization
clc;clear
addpath(fullfile(pwd, '/functions'));
Options = simset('SrcWorkSpace','current');
Ts = 0.01;
%% Parameter setup
%Motor related in SI:
k_b = (24-24*0.073/2.28)/(8300*2*pi/60);
k_t = k_b;
R_w = 10.7884;
r_p = 0.005;
m = 0.5;  %0.5kg for weighted carriage
J = 1.5e-6;
B = 2.242e-6;
continuous_plant = get_continuous_tf(k_b,k_t,R_w,r_p,m,J,B);
discrete_plant = c2d(continuous_plant,Ts);

%% Design PI controller via pole placement
settling_time = 0.3;
% OS = 7.0627e-05;
OS = 0.01;
[pp_controller,kp,ki,Ts_maximum] = get_pp_from_plant(OS,settling_time,Ts,continuous_plant);

%% Design Deadbeat Controller (CLTF = 1/z)
DeadbeatController = get_velocity_deadbeat_from_plant(discrete_plant,Ts);

%% Get step response result from simulated system
end_time = 1;
t = 0:Ts:end_time;
r = ones(length(t),1);
step = timeseries(r,t);
simin = step;

ControllerNumerator = cell2mat(pp_controller.Numerator);
ControllerDenominator = cell2mat(pp_controller.Denominator);
sim_result_pp_step = sim('MotorSlider_simulated.slx',end_time,Options);

ControllerNumerator = cell2mat(DeadbeatController.Numerator);
ControllerDenominator = cell2mat(DeadbeatController.Denominator);
sim_result_db_step = sim('MotorSlider_simulated.slx',end_time,Options);

figure
plot(sim_result_pp_step.Velocity,'DisplayName','Pole placement');
hold on
plot(step,'DisplayName','Input')  
hold on
plot(sim_result_db_step.Velocity,'DisplayName','Deadbeat');
title("Step response of simulated system")
xlabel("time (s)")
ylabel("Velocity (m/s)")
legend
%% Get sinusoidal response result from simulated system
end_time = 10;
t = 0:Ts:end_time;
r = sin(t);
sinusoidal = timeseries(r,t);
simin = timeseries(r,t);

ControllerNumerator = cell2mat(pp_controller.Numerator);
ControllerDenominator = cell2mat(pp_controller.Denominator);
sim_result_pp_sin = sim('MotorSlider_simulated.slx',end_time,Options);

ControllerNumerator = cell2mat(DeadbeatController.Numerator);
ControllerDenominator = cell2mat(DeadbeatController.Denominator);
sim_result_db_sin = sim('MotorSlider_simulated.slx',end_time,Options);

%Tracking error measurement
pp_RMS = sum(sqrt((sim_result_pp_sin.Velocity.Data - transpose(sin(t)))).^2)/length(t);
db_RMS = sum(sqrt((sim_result_db_sin.Velocity.Data - transpose(sin(t)))).^2)/length(t);
figure
plot(sim_result_pp_sin.Velocity,'.','DisplayName',append('Pole placement, RMS error = ',num2str(pp_RMS)));
hold on
plot(sinusoidal,'DisplayName','Input')  
hold on
plot(sim_result_db_sin.Velocity,'.','DisplayName',append('Deadbeat, RMS error = ',num2str(db_RMS)));
title("Sinusoidal response of simulated system")
xlabel("time (s)")
ylabel("Velocity (m/s)")
legend
%% Get sawtooth response result from simulated system
end_time = 10;
t = 0:Ts:end_time;
r = 0.5*(sawtooth(t,1/2))+0.5;
seesaw = timeseries(r,t);
simin = timeseries(r,t);

ControllerNumerator = cell2mat(pp_controller.Numerator);
ControllerDenominator = cell2mat(pp_controller.Denominator);
sim_result_pp_seesaw = sim('MotorSlider_simulated.slx',end_time,Options);

ControllerNumerator = cell2mat(DeadbeatController.Numerator);
ControllerDenominator = cell2mat(DeadbeatController.Denominator);
sim_result_db_seesaw = sim('MotorSlider_simulated.slx',end_time,Options);

%Tracking error measurement
pp_RMS = sum(sqrt(sim_result_pp_seesaw.Velocity.Data - transpose(sawtooth(t))).^2)/length(t);
db_RMS = sum(sqrt(sim_result_db_seesaw.Velocity.Data - transpose(sawtooth(t))).^2)/length(t);
figure
plot(sim_result_pp_seesaw.Velocity,'.','DisplayName',append('Pole placement, RMS error = ',num2str(pp_RMS)));
hold on
plot(seesaw,'DisplayName','Input')  
hold on
plot(sim_result_db_seesaw.Velocity,'.','DisplayName',append('Deadbeat, RMS error = ',num2str(db_RMS)));
title("Sawtooth response of simulated system")
xlabel("time (s)")
ylabel("Velocity (m/s)")
legend
